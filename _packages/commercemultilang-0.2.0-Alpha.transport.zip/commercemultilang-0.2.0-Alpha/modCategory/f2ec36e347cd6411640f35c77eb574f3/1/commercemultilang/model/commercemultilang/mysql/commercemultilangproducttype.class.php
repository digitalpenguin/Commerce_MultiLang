<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangproducttype.class.php');
class CommerceMultiLangProductType_mysql extends CommerceMultiLangProductType {}
?>
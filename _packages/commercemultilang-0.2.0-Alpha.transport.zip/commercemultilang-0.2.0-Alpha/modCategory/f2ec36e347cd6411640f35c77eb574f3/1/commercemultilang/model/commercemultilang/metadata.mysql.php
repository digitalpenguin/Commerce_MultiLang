<?php

$xpdo_meta_map = array (
  'comProduct' => 
  array (
    0 => 'CommerceMultiLangProduct',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'CommerceMultiLangProductData',
    1 => 'CommerceMultiLangProductLanguage',
    2 => 'CommerceMultiLangProductImage',
    3 => 'CommerceMultiLangProductImageLanguage',
    4 => 'CommerceMultiLangProductType',
    5 => 'CommerceMultiLangProductVariation',
    6 => 'CommerceMultiLangProductVariationLanguage',
    7 => 'CommerceMultiLangAssignedVariation',
  ),
);
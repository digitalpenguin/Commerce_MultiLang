<?php
/**
 * @package commercemultilang
 */
class CommerceMultiLangProductVariation extends xPDOSimpleObject {}
?>
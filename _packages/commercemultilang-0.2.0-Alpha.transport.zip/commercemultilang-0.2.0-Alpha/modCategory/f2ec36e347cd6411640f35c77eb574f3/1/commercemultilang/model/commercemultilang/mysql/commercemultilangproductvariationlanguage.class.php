<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangproductvariationlanguage.class.php');
class CommerceMultiLangProductVariationLanguage_mysql extends CommerceMultiLangProductVariationLanguage {}
?>
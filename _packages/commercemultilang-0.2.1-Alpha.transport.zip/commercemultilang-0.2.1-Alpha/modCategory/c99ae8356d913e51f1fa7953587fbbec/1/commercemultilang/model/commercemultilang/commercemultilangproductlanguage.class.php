<?php
/**
 * @package commercemultilang
 */
class CommerceMultiLangProductLanguage extends xPDOSimpleObject {}
?>
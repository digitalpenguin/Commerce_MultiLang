<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangproductvariation.class.php');
class CommerceMultiLangProductVariation_mysql extends CommerceMultiLangProductVariation {}
?>
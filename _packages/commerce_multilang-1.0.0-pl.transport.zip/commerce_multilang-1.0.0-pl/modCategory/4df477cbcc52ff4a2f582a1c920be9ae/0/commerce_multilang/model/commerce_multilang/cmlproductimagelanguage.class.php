<?php
/**
 * @package commerce_multilang
 */
class CMLProductImageLanguage extends xPDOSimpleObject {}
?>
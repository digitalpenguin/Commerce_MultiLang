<?php
/**
 * @package commerce_multilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/cmlproduct.class.php');
class CMLProduct_mysql extends CMLProduct {}
?>
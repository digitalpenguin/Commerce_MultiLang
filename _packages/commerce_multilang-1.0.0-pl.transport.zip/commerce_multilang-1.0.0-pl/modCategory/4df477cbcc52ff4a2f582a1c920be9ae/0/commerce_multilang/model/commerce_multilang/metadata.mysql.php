<?php

$xpdo_meta_map = array (
  'comProduct' => 
  array (
    0 => 'CMLProduct',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'CMLProductLanguage',
    2 => 'CMLProductImage',
    3 => 'CMLProductImageLanguage',
  ),
);
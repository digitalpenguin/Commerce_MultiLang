<?php
/**
 * @package commerce_multilang
 */
class CMLProductLanguage extends xPDOSimpleObject {}
?>
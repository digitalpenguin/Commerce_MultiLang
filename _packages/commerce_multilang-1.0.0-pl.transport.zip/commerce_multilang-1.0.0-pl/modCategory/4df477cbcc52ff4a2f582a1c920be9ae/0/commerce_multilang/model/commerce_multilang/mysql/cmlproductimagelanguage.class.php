<?php
/**
 * @package commerce_multilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/cmlproductimagelanguage.class.php');
class CMLProductImageLanguage_mysql extends CMLProductImageLanguage {}
?>
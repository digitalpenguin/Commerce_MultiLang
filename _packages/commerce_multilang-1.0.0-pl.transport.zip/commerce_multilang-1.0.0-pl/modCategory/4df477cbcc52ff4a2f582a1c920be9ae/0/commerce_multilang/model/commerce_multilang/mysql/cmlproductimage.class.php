<?php
/**
 * @package commerce_multilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/cmlproductimage.class.php');
class CMLProductImage_mysql extends CMLProductImage {}
?>
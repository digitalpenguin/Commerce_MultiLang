<?php
/**
 * @package commerce_multilang
 */
class CMLProductImage extends xPDOSimpleObject {}
?>
<?php
/**
 * @package commercemultilang
 */
class CommerceMultiLangProductImage extends xPDOSimpleObject {}
?>
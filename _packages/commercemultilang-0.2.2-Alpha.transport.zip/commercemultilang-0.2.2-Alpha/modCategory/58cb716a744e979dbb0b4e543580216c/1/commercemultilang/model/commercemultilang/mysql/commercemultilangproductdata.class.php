<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangproductdata.class.php');
class CommerceMultiLangProductData_mysql extends CommerceMultiLangProductData {}
?>
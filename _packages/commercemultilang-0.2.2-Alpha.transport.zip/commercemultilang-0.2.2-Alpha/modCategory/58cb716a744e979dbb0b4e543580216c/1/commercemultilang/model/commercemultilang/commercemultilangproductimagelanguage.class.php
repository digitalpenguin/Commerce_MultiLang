<?php
/**
 * @package commercemultilang
 */
class CommerceMultiLangProductImageLanguage extends xPDOSimpleObject {}
?>
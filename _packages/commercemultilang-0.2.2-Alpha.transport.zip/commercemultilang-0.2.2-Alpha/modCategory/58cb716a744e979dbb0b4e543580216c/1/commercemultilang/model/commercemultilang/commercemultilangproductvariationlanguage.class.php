<?php
/**
 * @package commercemultilang
 */
class CommerceMultiLangProductVariationLanguage extends xPDOSimpleObject {}
?>
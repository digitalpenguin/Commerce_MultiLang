<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangproductlanguage.class.php');
class CommerceMultiLangProductLanguage_mysql extends CommerceMultiLangProductLanguage {}
?>
<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangassignedvariation.class.php');
class CommerceMultiLangAssignedVariation_mysql extends CommerceMultiLangAssignedVariation {}
?>
<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangproduct.class.php');
class CommerceMultiLangProduct_mysql extends CommerceMultiLangProduct {}
?>
<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangproductimagelanguage.class.php');
class CommerceMultiLangProductImageLanguage_mysql extends CommerceMultiLangProductImageLanguage {}
?>
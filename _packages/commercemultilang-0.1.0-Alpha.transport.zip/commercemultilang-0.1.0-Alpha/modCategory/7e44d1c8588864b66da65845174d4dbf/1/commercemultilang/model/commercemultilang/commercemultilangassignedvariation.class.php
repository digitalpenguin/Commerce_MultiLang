<?php
/**
 * @package commercemultilang
 */
class CommerceMultiLangAssignedVariation extends xPDOSimpleObject {}
?>
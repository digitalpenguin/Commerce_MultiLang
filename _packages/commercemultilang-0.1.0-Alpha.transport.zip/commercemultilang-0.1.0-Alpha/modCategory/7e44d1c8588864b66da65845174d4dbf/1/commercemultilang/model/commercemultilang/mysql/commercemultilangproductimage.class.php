<?php
/**
 * @package commercemultilang
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/commercemultilangproductimage.class.php');
class CommerceMultiLangProductImage_mysql extends CommerceMultiLangProductImage {}
?>
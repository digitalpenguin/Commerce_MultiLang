<?php
/**
 * @package commercemultilang
 */
class CommerceMultiLangProductData extends xPDOSimpleObject {}
?>
<?php
/**
 * @package commercemultilang
 */
class CommerceMultiLangProductType extends xPDOSimpleObject {}
?>